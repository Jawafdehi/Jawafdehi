# Jawafdehi — Press Kit

Everything in this folder is cleared for publication. Please use the files as they are.

**Writing a story? Start with the FAQ.** It covers why Jawafdehi was started, the problem it solves, who it is for, what is on the platform, and what we deliberately do not publish:

**https://docs.google.com/document/d/1o7vkXuLldx5UsNEGoHxCkx2jUfhOOB5Shdu-yzG9qnY/edit**

For anything not covered here or in the FAQ, or for an interview, a comment, or a higher-resolution asset: **inquiry@jawafdehi.org**

---

## The name

**जवाफदेही** · **Jawafdehi** — the word means *accountability* in Nepali. In English we keep the name "Jawafdehi" and gloss it as "accountability" on first use.

Registered name: **Jawafdehi Initiative** · **जवाफदेही इनिशिएटिभ**

The Nepali spelling is standardised. Please use it exactly as written above — दीर्घ **ही**, **श** (not स), **भ** (not व). The common noun *जवाफदेहिता* ("accountability") takes ह्रस्व **हि** and is a different word; both spellings above are correct in their own place.

Website: **https://jawafdehi.org**

---

## One-line descriptor

Use the longest version that fits your space. Please don't paraphrase — this wording is fixed.

**Nepali**

> नेपालको स्थायी भ्रष्टाचार अभिलेख — को, के र कहिले।

**English — long (140 characters)**

> Nepal's Permanent Corruption Case Archive. We arrange corruption-related evidence and facts into a structured format of who, what, and when.

**English — medium (100 characters)**

> Nepal's Permanent Corruption Case Archive. Corruption evidence, structured into who, what, and when.

**English — short (64 characters)**

> Nepal's Permanent Corruption Case Archive — who, what, and when.

---

## About

This is the text published on our own site. Quote it as our description of ourselves.

### नेपाली

Jawafdehi.org नेपालका लागि एक open-source नागरिक प्रविधि प्लेटफर्म हो, जसले भ्रष्टाचारसम्बन्धी आरोपहरू व्यवस्थित रूपमा अभिलेख गर्छ। Gen-Z पुस्ताको पारदर्शिता र जवाफदेहीताको मागमा आधारित यस पहलले नेपालमा संस्थागत उत्तरदायित्व प्रणाली विकास गर्ने लक्ष्य राखेको छ, जसले दीर्घकालीन दण्डहीनताको संस्कृतिको अन्त्यतर्फ योगदान पुर्‍याउनेछ। स्वतन्त्र, प्रमाण-आधारित र नागरिक–संचालित प्रक्रियामार्फत भ्रष्ट राजनीतिज्ञ, व्यक्ति तथा अन्य सरोकारवालालाई उत्तरदायी बनाउनु यसको उद्देश्य हो। सरकारी कागजातहरूको डिजिटाइजेसन (digitization), समाचार स्रोतहरूको अनुगमन र विस्तृत अनुसन्धान प्रतिवेदन तयार पार्न AI प्रविधिको उपयोग गर्दै Jawafdehi.org ले प्रविधिमार्फत भ्रष्टाचारविरुद्धको पहललाई विस्तार र सुदृढ बनाउने प्रयास गर्दछ।

### English

Jawafdehi is an open-source civic-tech platform for Nepal built by Nepali to document allegations of corruption. Grounded in a Gen-Z mandate for transparency and action, Jawafdehi aims to become the Nepali accountability system to bring an end to the practice of unaccountability — holding corrupt politicians, individuals, and others accountable through independent, evidence-first, and citizen-powered means. Using AI to process government documents, track news sources, and generate comprehensive investigation reports, Jawafdehi scales the fight against corruption through technology.

---

## Logo

The logo is a database cylinder carrying the Nepal flag, locked up with the Devanagari wordmark जवाफदेही.

| File | What it is | Use it on |
|---|---|---|
| `logo/jawafdehi-logo-navy-for-light-bg.png` | Navy wordmark, transparent, 1161×270 | White and light backgrounds |
| `logo/jawafdehi-logo-white-for-dark-bg.png` | Off-white wordmark, transparent, 1161×270 | Navy, black and dark backgrounds |
| `logo/jawafdehi-mark-square.png` | The mark alone on white, 1080×1080 | Thumbnails, avatars, square slots |
| `logo/jawafdehi-mark-square-transparent.png` | The same mark, transparent, 1080×1080 | Square slots over a colour of your own |
| `logo/*.svg` | Vector masters of both wordmarks | Print, large format, or any size |

Every file above carries the brand navy and crimson below.

### Rules

**Match the variant to the background.** The navy wordmark on a dark field disappears; the off-white wordmark on a light field disappears. Both failures have happened in production, so this is the one rule worth checking twice.

**Keep clear space** of 16% of the logo's height on all four sides. The files are not pre-padded, so this has to come from your layout.

**Minimum size is 24 px tall** for the full lockup. Below that the ी matra collapses into the letter beside it and the flag inside the mark turns into a blob — use the square mark alone instead.

**Please don't** stretch it (the lockup is 4.30:1 and must stay there), re-draw it, re-space it, re-colour it, or place it on a photograph without a solid field behind it. To change its colour, switch to the other variant — that is what the pair is for.

---

## Colours

The hex value is the canonical one.

| Role | Hex |
|---|---|
| Primary — Navy | `#0E1F3B` |
| Accent — Crimson | `#B5242C` |
| Accent on dark backgrounds | `#F04C54` |
| Background — warm white | `#FAFAF7` |
| Body text | `#1F2937` |

Crimson is never set as text on navy — the contrast is only 2.6:1. Use `#F04C54` there instead. Our background is the warm white `#FAFAF7`, not pure `#FFFFFF`.

---

## Typography

| Role | Typeface |
|---|---|
| Display and headings | Vesper Libre |
| Body and UI | Noto Sans Devanagari |
| Figures, dates, case references | IBM Plex Mono |

Vesper Libre covers both Latin and Devanagari, so a bilingual headline stays in one face. Devanagari needs its own metrics — looser leading than Latin — because of matra stacking; please don't set Devanagari copy on Latin metrics.

---

## Contact

| For | Address |
|---|---|
| Press, interviews, general enquiries | inquiry@jawafdehi.org |
| Reporting a case or sending a tip | https://jawafdehi.org/report — or report@jawafdehi.org |
| Data and deletion requests | privacy@jawafdehi.org |

Anyone can submit a case through the report form, anonymously or named. Every submission is reviewed by our team before anything is published.

### Channels

- **Website** — https://jawafdehi.org
- **Report a case** — https://jawafdehi.org/report
- **WhatsApp** — @jawafdehi · +977 9768630501 · https://api.whatsapp.com/send?phone=9779768630501
- **Facebook** — https://www.facebook.com/jawafdehi
- **YouTube** — https://www.youtube.com/@Jawafdehi
- **Instagram** — https://www.instagram.com/jawafdehi
- **TikTok** — https://www.tiktok.com/@jawafdehi
- **LinkedIn** — https://www.linkedin.com/company/jawafdehi
- **X** — https://x.com/jawafdehi
- **All links** — https://linktr.ee/jawafdehi
